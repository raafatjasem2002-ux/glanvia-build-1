# Project memory

## Product intent & audience

- App purpose not yet defined. User request ("ggh") was ambiguous; assistant asked for clarification (e.g., portfolio, to-do list, landing page, recipe app). Awaiting a concrete product description.

## Brand personality & voice

- No brand or tone inferred yet; pending product clarification.

## Visual design & UX direction

- No product-specific visual direction inferred yet. Global UI/design expectations live in `.bolt/prompt` and are authoritative.
- Stack context (from template/framework, not prompt): React + Vite, JSX, Tailwind CSS, React hooks, Lucide React icons, `@/` path alias to `src/`.

## Decisions, constraints & rationale

- Clarification requested before building; no implementation decisions made yet.
- Treat `.bolt/prompt` as authoritative for global build/design instructions; do not duplicate here.

## Open questions & assumptions

- What product/app should be built? (Primary blocker.)
- Target audience, features, and scope still unknown.
- Assumption: user will provide a clearer description next turn before implementation proceeds.